 Dataset Base 1 sendo a base para preenchimento dos resultados das bases adiantes.

* Base 1 - Resultado do Brasileirão 2003 - 2022
  - Dataset: https://www.kaggle.com/datasets/regazze/brasileirao-2003-2022

* Base 2 = Ranking CONMEBOL de alguns times
  - 2021/2022: https://conmebollibertadores.com/cards/NewsReaderWeb/ranking-de-clubes-conmebol-2022-veja-como-ficou
  - 2022/2023: https://conmebollibertadores.com/cards/NewsReaderWeb/confira-o-ranking-de-clubes-conmebol-2023
  - rank_tm